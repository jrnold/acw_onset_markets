#' mcmcstats package
#' 
#' @name mcmcStats
#' @docType package
#' @import mcmcse
#' @import plyr
#' @importFrom coda spectrum0
NULL
