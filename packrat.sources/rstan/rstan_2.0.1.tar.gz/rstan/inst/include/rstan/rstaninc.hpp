#ifndef __RSTAN__RSTANINC_HPP__
#define __RSTAN__RSTANINC_HPP__
#include <rstan/stan_fit.hpp>
#endif 

