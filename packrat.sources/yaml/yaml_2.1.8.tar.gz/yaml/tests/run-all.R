library(testthat)
library(yaml)

test_package('yaml')
