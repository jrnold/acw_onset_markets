library(testthat)
library(lubridate)

test_package("lubridate")
