### R code from vignette source 'rstan.Rnw'

###################################################
### code chunk number 1: rstan.Rnw:76-77
###################################################
options(width=60)


###################################################
### code chunk number 2: rstan.Rnw:293-297
###################################################
schools_data <- 
  list(J=8, 
  y=c(28,  8, -3,  7, -1,  1, 18, 12),
  sigma=c(15, 10, 16, 11,  9, 11, 10, 18))


###################################################
### code chunk number 3: rstan.Rnw:304-308
###################################################
J <- 8
y <- c(28,  8, -3,  7, -1,  1, 18, 12)
sigma <- c(15, 10, 16, 11,  9, 11, 10, 18)
schools_data <- c("J", "y", "sigma") 


###################################################
### code chunk number 4: callstan
###################################################
library(rstan)
fit1 <- stan(file="schools.stan", data=schools_data, 
             iter=100, chains=4)


###################################################
### code chunk number 5: rstan.Rnw:359-361
###################################################
print(fit1, pars=c("theta", "mu", "tau", "lp__"), 
      probs=c(.1,.5,.9))


###################################################
### code chunk number 6: rstan.Rnw:387-389
###################################################
rt <- stanc(file = "schools.stan",
            model_name = '8schools') 


###################################################
### code chunk number 7: callstanmodel
###################################################
sm <- stan_model(stanc_ret = rt, verbose = FALSE)


###################################################
### code chunk number 8: callstanmodel2
###################################################
sm <- stan_model(file="schools.stan",
                 model_name='schools', 
                 verbose=FALSE)


###################################################
### code chunk number 9: callcampling
###################################################
fit <- sampling(sm, data=schools_data, chains=4)


###################################################
### code chunk number 10: rstan.Rnw:518-519
###################################################
y <- as.array(y)


###################################################
### code chunk number 11: stanfit_plot
###################################################
plot(fit)


###################################################
### code chunk number 12: stanfit_tplot
###################################################
traceplot(fit, pars = "tau")


###################################################
### code chunk number 13: rstan.Rnw:614-621
###################################################
s <- extract(fit, pars = c("theta", "mu"), permuted = TRUE)
names(s)
dim(s$theta)
dim(s$mu)
s2 <- extract(fit, pars = "theta", permuted = FALSE)
dim(s2)
dimnames(s2)


###################################################
### code chunk number 14: optimizer
###################################################
ocode <- "
  data {
    int<lower=1> N;
    real y[N];
  } 
  parameters {
    real mu;
  } 
  model {
    y ~ normal(mu, 1);
  } 
"

sm <- stan_model(model_code = ocode)
y2 <- rnorm(20)
mean(y2)
op <- optimizing(sm, data = list(y = y2, N = length(y2)))
print(op)


###################################################
### code chunk number 15: parallel
###################################################
library(rstan)
library(parallel)
f1 <- stan(file="schools.stan",data=schools_data, 
           chains =1, iter=1)
WINDOWS <- .Platform$OS.type == "windows"
seed <- 12345 
sflist1 <-
  mclapply(1:4, mc.cores = ifelse(WINDOWS, 1, 4),
           function(i) stan(fit = f1, seed = seed, 
                            data = schools_data, 
                            chains = 1, chain_id = i, 
                            refresh = -1))
fit <- sflist2stanfit(sflist1)


